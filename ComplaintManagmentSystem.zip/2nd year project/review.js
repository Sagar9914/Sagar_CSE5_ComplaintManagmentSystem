// Load reviews from localStorage when page loads
window.onload = function () {
    const storedReviews = JSON.parse(localStorage.getItem("customerReviews")) || [];
    storedReviews.forEach(review => renderReview(review));
  };
  
  function toggleForm() {
    const form = document.getElementById("reviewForm");
    form.classList.toggle("form-hidden");
  }
  
  function addReview() {
    const name = document.getElementById("name").value.trim();
    const reviewText = document.getElementById("reviewText").value.trim();
    const rating = document.getElementById("rating").value;
  
    if (!name || !reviewText) {
      alert("Please fill out all fields");
      return;
    }
  
    const today = new Date();
    const dateStr = today.toLocaleDateString("en-US", {
      month: "long", day: "numeric"
    });
  
    const newReview = {
      name,
      reviewText,
      rating,
      date: dateStr
    };
  
    // Save to localStorage
    let reviews = JSON.parse(localStorage.getItem("customerReviews")) || [];
    reviews.unshift(newReview); // Add to beginning
    localStorage.setItem("customerReviews", JSON.stringify(reviews));
  
    // Show on screen
    renderReview(newReview);
  
    // Clear form
    document.getElementById("name").value = "";
    document.getElementById("reviewText").value = "";
    document.getElementById("rating").value = "5";
    toggleForm();
  }
  
  // Function to render one review on the page
  function renderReview(review) {
    const reviewsDiv = document.getElementById("reviews");
    const reviewCard = document.createElement("div");
    reviewCard.className = "review-card";
  
    reviewCard.innerHTML = `
      <h4>${review.name}</h4>
      <div class="stars">${"⭐".repeat(review.rating)}</div>
      <div class="date">${review.date}</div>
      <p>${review.reviewText}</p>
    `;
  
    reviewsDiv.prepend(reviewCard);
  }
  