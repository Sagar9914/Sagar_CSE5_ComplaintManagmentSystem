const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MySQL Connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',       // your MySQL password
  database: 'complaints_db'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL Database');
});

// API to submit a complaint
app.post('/submit-complaint', (req, res) => {
  const { name, email, complaint, complaintId } = req.body;
  const query = 'INSERT INTO complaints (name, email, complaint, complaint_id) VALUES (?, ?, ?, ?)';
  db.query(query, [name, email, complaint, complaintId], (err, result) => {
    if (err) throw err;
    res.send({ status: 'success', id: complaintId });
  });
});

// API to track complaint
app.get('/track-complaint/:id', (req, res) => {
  const complaintId = req.params.id;
  const query = 'SELECT * FROM complaints WHERE complaint_id = ?';
  db.query(query, [complaintId], (err, result) => {
    if (err) throw err;
    res.send(result.length ? result[0] : { message: 'No complaint found' });
  });
});

app.listen(5000, () => console.log('Server running on port 5000'));
